fp = open('db.txt' ,'r')

print fp.read()

print type(fp.read())
