#!/usr/bin/env python
from migrate.versioning.shell import main

if __name__ == '__main__':
    main(six='<module 'six' from 'E:\workspace\microblog\flask\lib\site-packages\six.pyc'>')
