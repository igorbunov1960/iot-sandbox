# tictactoe

A simple webbrowser game created to experiment with AJAX. Server side AI (justification to use AJAX) is 100% retarted, i.e. fully random.
