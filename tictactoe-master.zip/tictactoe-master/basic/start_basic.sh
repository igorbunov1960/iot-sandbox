#! /bin/bash

FLASK_APP=basic/server.py flask run -p 5001
