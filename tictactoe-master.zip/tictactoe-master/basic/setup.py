from setuptools import setup

setup(name='basic',
      version='0.1',
      packages=['basic'],
      install_requires=["flask", ])

