#! /bin/bash

FLASK_APP=tictactoe/server.py flask run
