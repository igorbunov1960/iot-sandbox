from setuptools import setup

setup(name='tictactoe',
      version='0.1',
      packages=['tictactoe'],
      install_requires=["flask", ])

