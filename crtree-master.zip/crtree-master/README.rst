Costa Rica Tree Demo
====================

Dependencies
------------

::

    sudo apt-get install python-pip
    sudo pip install flask

Running
-------

::

   ./backend.py
