# Flask Ajax example

shows how to make an ajax request using flask.

run using `FLASK_APP=app.py flask run`
